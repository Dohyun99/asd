Please note the following details about the model which must be communicated to the user:

1. Our board provider has created this 3D model with the front panel, connectors and main large components only.

2. The dimensions of the components in this 3D model are of typical values. Please bear in mind that in reality, they may vary within the allowed range. The underlying component models may have some differences from the actual parts used for the assembly, but this has not been checked in detail.

3. GR740 package representation in this 3D model is of type GR740-CG625. User must rely on GR740 datasheet(https://www.gaisler.com/doc/gr740/GR740-UM-DS-2-3.pdf) section 40.4 for actual package dimension values of GR740, rather than this model. Data sheet explains package dimensions for both GR740-CG625 and GR740-LG625.
